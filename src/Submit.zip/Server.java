import java.util.*;

import edu.purdue.cs.cs180.channel.*;

public class Server implements MessageListener {
    /**
     * Creates a server channel on the current machine and assigns port 8888 to it.
     */
    private Channel channel;
    private LinkedList < String > requests; //requests
    private LinkedList < String > volunteer; //volunteers
    private LinkedList < Integer > recID; //requests
    private LinkedList < Integer > volID; //volunteers
    /**
     * Constructor.
     */
    public Server(Channel channel) {
        // inform the channel that when new messages are received forward them
        // to the current server object.
        this.channel = channel;
        openPort();
    }
    /**
     * Opens the TCP port on the current machine for listening.
     * initializes the linked lists.
     * @param port
     */
    public void openPort() {
        channel.setMessageListener(this);
        requests = new LinkedList < String > ();
        volunteer = new LinkedList < String > ();
        recID = new LinkedList < Integer > ();
        volID = new LinkedList < Integer > ();
    }

    public void messageReceived(String message, int clientID) {

        if (message.substring(0, 7).equals("REQUEST")) {

            if (volunteer.size() == 0) { // if there is no volunteers, add to queue
                recID.add(clientID); // add client id to a list
                requests.add(message.substring(8, message.length()));
            } else if (volunteer.size() > 0) {
                try {
                    channel.sendMessage("LOCATION " + message.substring(7, message.length()), volID.removeFirst());
                    channel.sendMessage("VOLUNTEER " + volunteer.removeFirst(), clientID);
                } catch (ChannelException e) {
                    e.printStackTrace();
                }
            }
        } else if (message.substring(0, 9).equals("VOLUNTEER")) {
            if (requests.size() == 0) {
                volID.add(clientID); //adds the client id of the volunteer to a list
                volunteer.add(message.substring(10, message.length()));
            } else if (requests.size() > 0) {
                try {
                    channel.sendMessage("LOCATION " + requests.removeFirst(), clientID);
                    channel.sendMessage("VOLUNTEER " + message.substring(10, message.length()), recID.removeFirst());
                } catch (NumberFormatException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (ChannelException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
    }
    /**
     * constructs a new Server with the port at position args[0] ex. java Server 8888 runs with the port 8888
     */

    public static void main(String[] args) {
        new Server(new TCPChannel(8888));
    }
}